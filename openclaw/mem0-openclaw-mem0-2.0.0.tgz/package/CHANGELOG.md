# Changelog

All notable changes to the Mem0 OpenClaw Plugin.

## [2.0.0] - 2026-03-07

### Release Summary

Mem0 Plugin v2.0.0 is a complete rewrite with three-tier memory architecture, server mode support, and comprehensive testing. All 23 tests passed with 100% pass rate and excellent performance ratings.

### Deployment Updates (2026-03-07 14:00)
- **Data Directory** - Changed from `/opt/mem0-data` to `/home/yhz/mem0-data`
- **External Access** - Server binds to `0.0.0.0:8000` for LAN/external access
- **PostgreSQL Connection** - Changed from hardcoded IP to container name (`mem0-postgres`)
- **Container Cleanup** - Removed duplicate `mem0-api` container (port 8888)
- **Documentation** - Updated all docs with new deployment configuration

### Critical Fix (2026-03-07 04:30)
- **Server Mode Implementation** - Added full ServerProvider class to index.ts
- **L0/L1 Integration** - Integrated L0Manager and L1Manager into main plugin
- **Configuration Support** - Added serverUrl, serverApiKey, agentId, and all L0/L1 config keys
- **Auto-Recall Enhancement** - Now includes L0/L1 content alongside L2 vector search
- **Auto-Capture Enhancement** - L1 auto-write when enabled

### Test Results (2026-03-07)

**功能测试**: 23/23 通过 (100%)

| 阶段 | 测试数 | 状态 |
|------|--------|------|
| 基础健康检查 | 2 | ✅ |
| CRUD 功能测试 | 6 | ✅ |
| 批量操作测试 | 2 | ✅ |
| 性能测试 | 4 | ✅ |
| 多 Agent 隔离测试 | 2 | ✅ |
| 错误处理测试 | 3 | ✅ |
| L0/L1 记忆层测试 | 3 | ✅ |
| 清理测试数据 | 1 | ✅ |

**性能测试结果**:

| 操作 | 平均延迟 | P95 | 吞吐量 |
|------|---------|-----|--------|
| 健康检查 | 15ms | 18ms | 69 req/s |
| 搜索记忆 | 82ms | 101ms | 10 req/s |
| 获取全部 | 20ms | 43ms | 33 req/s |
| 创建记忆(含LLM) | 5.5s | 5.8s | 0.18 req/s |
| 更新记忆 | 16ms | 22ms | 43 req/s |
| 获取历史 | 14ms | 18ms | 52 req/s |
| 并发(50) | 137ms | - | 365 req/s |

**总体评级**: ⭐⭐⭐⭐⭐ 优秀 (100分)

### Added

- **Three-Tier Memory Architecture** - L0 (memory.md) + L1 (date/category files) + L2 (vector search)
- **L0Manager** - Fast persistent memory layer for critical user facts
- **L1Manager** - Structured context layer with date and category files
- **Server Mode Support** - New provider for Enhanced Mem0 Server
- **Multi-Agent Isolation** - Per-agent memory collection isolation
- **Automatic Retry** - ServerClient with 3-retry exponential backoff
- **OpenClaw Systemd Service** - Native systemd integration for auto-start
- **Comprehensive Test Suite** - 23 tests with 100% pass rate
- **Performance Benchmark** - Detailed latency and throughput metrics

### Changed

- **Plugin Version** - Upgraded from 0.1.2 to 2.0.0
- **Provider Architecture** - Unified interface for Platform, OSS, and Server providers
- **API Compatibility** - Fixed PlatformProvider API calls to use camelCase (organizationId, projectId)
- **Configuration Schema** - Extended with server mode and L0/L1 options

### Fixed

- **PlatformProvider API Call** - Fixed snake_case to camelCase for organizationId and projectId
- **L1Manager Missing Method** - Added isAutoWriteEnabled() method
- **TypeScript Types** - Fixed type definitions and ClientOptions compatibility
- **Server Mode Support** - Added full ServerProvider implementation
- **Memory ID Extraction** - Fixed regex for proper ID capture in tests

### Performance

| Metric | Value | Rating |
|--------|-------|--------|
| Health Check | 15ms | ⭐⭐⭐⭐⭐ |
| Database Query | 20ms | ⭐⭐⭐⭐⭐ |
| Vector Search | 82ms | ⭐⭐⭐⭐⭐ |
| Concurrent Throughput | 365 req/s | ⭐⭐⭐⭐⭐ |
| Memory Update | 16ms | ⭐⭐⭐⭐⭐ |

### Documentation

- Updated README.md - Added performance section and systemd setup
- Updated BEGINNER_GUIDE.md - Complete beginner tutorial
- Updated INSTALLATION_GUIDE.md - Server mode configuration
- Updated DEPLOYMENT_GUIDE.md - Production deployment with systemd
- Updated TEST_REPORT.md - Latest test results
- Updated docs/ARCHITECTURE.md - Three-tier architecture details
- Updated docs/DEPLOYMENT.md - Systemd service setup

---

## [0.1.2] - Previous Release

### Features
- Platform mode support
- Open-source mode support
- Auto-recall and auto-capture hooks
- 7 agent tools

---

## Upgrade Guide

### From 0.1.2 to 2.0.0

1. Update plugin configuration to include new `server` mode option
2. Add L0/L1 settings if desired (`l0Enabled`, `l1Enabled`, etc.)
3. Update `openclaw.plugin.json` with new configuration schema
4. Run tests to verify installation:
   ```bash
   bash test_plugin_comprehensive.sh
   ```

### Configuration Changes

**Old Configuration (0.1.2)**:
```json5
{
  "mode": "platform",
  "apiKey": "${MEM0_API_KEY}",
  "userId": "default"
}
```

**New Configuration (2.0.0)**:
```json5
{
  "mode": "server",
  "serverUrl": "http://localhost:8000",
  "serverApiKey": "${MEM0_SERVER_API_KEY}",
  "agentId": "openclaw-main",
  "userId": "default",
  "l0Enabled": true,
  "l1Enabled": true,
  "l1AutoWrite": true
}
```

---

## Support

For support and issues:
- GitHub: https://github.com/mem0ai/mem0/issues
- Docs: https://docs.mem0.ai
- Community: https://discord.gg/mem0
