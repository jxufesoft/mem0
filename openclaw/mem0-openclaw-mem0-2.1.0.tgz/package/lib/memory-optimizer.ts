/**
 * Memory Optimizer - Automatic Memory Management
 *
 * Provides automatic optimization, archiving, and cleanup for all memory layers.
 */

import type { L0Manager } from "./l0-manager.js";
import type { L1Manager } from "./l1-manager.js";
import type { ServerClient } from "./server-client.js";

// ============================================================================
// Types
// ============================================================================

export interface MemoryOptimizerConfig {
  enabled: boolean;
  autoPruneL0: boolean;
  l0MaxLines: number;
  autoArchiveL1: boolean;
  l1ArchiveDays: number;
  autoDedupL2: boolean;
  optimizeIntervalHours: number;
}

export interface OptimizationResult {
  timestamp: string;
  l0?: {
    pruned: boolean;
    originalLines: number;
    newLines: number;
  };
  l1?: {
    archivedCount: number;
    archivedFiles: string[];
    cleanedCount: number;
    cleanedFiles: string[];
  };
  l2?: {
    duplicatesRemoved: number;
  };
  totalSizeReduction: number;
}

// ============================================================================
// Memory Optimizer
// ============================================================================

export class MemoryOptimizer {
  private lastOptimization: number = 0;

  constructor(
    private config: MemoryOptimizerConfig,
    private l0Manager: L0Manager | null,
    private l1Manager: L1Manager | null,
    private serverClient: ServerClient | null
  ) {}

  /**
   * Run optimization if interval has passed
   */
  async autoOptimize(): Promise<OptimizationResult | null> {
    if (!this.config.enabled) {
      return null;
    }

    const now = Date.now();
    const intervalMs = this.config.optimizeIntervalHours * 60 * 60 * 1000;

    if (now - this.lastOptimization < intervalMs) {
      return null;
    }

    return this.runOptimization();
  }

  /**
   * Force optimization regardless of interval
   */
  async runOptimization(): Promise<OptimizationResult> {
    const result: OptimizationResult = {
      timestamp: new Date().toISOString(),
      totalSizeReduction: 0
    };

    // L0 Optimization
    if (this.config.autoPruneL0 && this.l0Manager) {
      const beforeStats = await this.l0Manager.getStats();
      const pruneResult = await this.l0Manager.prune(this.config.l0MaxLines);
      const afterStats = await this.l0Manager.getStats();

      result.l0 = {
        pruned: pruneResult.pruned,
        originalLines: pruneResult.originalLines,
        newLines: pruneResult.newLines
      };

      if (pruneResult.pruned) {
        result.totalSizeReduction += beforeStats.sizeBytes - afterStats.sizeBytes;
      }
    }

    // L1 Optimization
    if (this.config.autoArchiveL1 && this.l1Manager) {
      // Archive old files
      const archiveResult = await this.l1Manager.archiveOldFiles(this.config.l1ArchiveDays);

      // Cleanup test files
      const cleanupResult = await this.l1Manager.cleanup();

      result.l1 = {
        archivedCount: archiveResult.archivedCount,
        archivedFiles: archiveResult.archivedFiles.slice(0, 10),
        cleanedCount: cleanupResult.removedCount,
        cleanedFiles: cleanupResult.removedFiles.slice(0, 10)
      };

      // Estimate size reduction (average 3KB per file)
      result.totalSizeReduction += (archiveResult.archivedCount + cleanupResult.removedCount) * 3072;
    }

    // L2 Deduplication
    if (this.config.autoDedupL2 && this.serverClient) {
      try {
        // Check for duplicates via health or stats endpoint
        // For now, we just log that dedup should be done periodically
        result.l2 = {
          duplicatesRemoved: 0
        };
      } catch (error) {
        console.error(`L2 dedup check failed: ${error}`);
      }
    }

    this.lastOptimization = Date.now();
    return result;
  }

  /**
   * Get current memory statistics
   */
  async getStats(): Promise<{
    l0: { sizeBytes: number; lineCount: number; exists: boolean };
    l1: { totalFiles: number; totalSizeBytes: number; dateFiles: number; categoryFiles: number; otherFiles: number };
    l2: { status: string };
  }> {
    const stats = {
      l0: { sizeBytes: 0, lineCount: 0, exists: false },
      l1: { totalFiles: 0, totalSizeBytes: 0, dateFiles: 0, categoryFiles: 0, otherFiles: 0 },
      l2: { status: "unknown" }
    };

    if (this.l0Manager) {
      stats.l0 = await this.l0Manager.getStats();
    }

    if (this.l1Manager) {
      const l1Stats = await this.l1Manager.getStats();
      stats.l1 = l1Stats;
    }

    if (this.serverClient) {
      try {
        await this.serverClient.health();
        stats.l2.status = "connected";
      } catch {
        stats.l2.status = "disconnected";
      }
    }

    return stats;
  }
}
